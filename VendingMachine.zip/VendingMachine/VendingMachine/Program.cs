﻿using System;

namespace VendingMachine
{
    class Program
    {


     
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome To Vending Machine");

            Console.WriteLine("Please Select Any  Product , 1.Cola 2.Chips and 3.Candy");
            int pId = Convert.ToInt32(Console.ReadLine());         
                      
            if (pId == 1)
            {
                Console.WriteLine("You Have Selected Cola");
                Console.WriteLine("Please Insert Coins");
              
                int amount, count, i;
                decimal[] coins = { 0.5m, 0.10m, 0.25m};
                for (i = 0; i < coins.Length; i++)
                {
                    Console.WriteLine("Count of {0} ", coins[i]);
                }

                    Console.ReadLine();

            }
            if (pId == 2)
            {
                Console.WriteLine("You Have Selected Cola");
                Console.WriteLine("Please Insert Coins");

                int amount, count, i;
                decimal[] coins = { 0.5m, 0.10m, 0.25m };
                for (i = 0; i < coins.Length; i++)
                {
                    Console.WriteLine("Count of {0} ", coins[i]);
                }

                Console.ReadLine();

            }
            if (pId == 3)
            {
                Console.WriteLine("You Have Selected Cola");
                Console.WriteLine("Please Insert Coins");

                int amount, count, i;
                decimal[] coins = { 0.5m, 0.10m, 0.25m };
                for (i = 0; i < coins.Length; i++)
                {
                    Console.WriteLine("Count of {0} ", coins[i]);
                }

                Console.ReadLine();
            }
            Console.ReadKey();
        }
    }
}
